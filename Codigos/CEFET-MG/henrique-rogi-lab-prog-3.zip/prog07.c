#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


/*
* Lab. de Programação de Computadores I - Laboratório 03
*
* Aluno(a): Henrique Soares Costa e Roginaldo Rebouças Rocha Junior
* Data: 25/11/2021
* Versão: 1.0
* Atividade 7 - Operações com os números
*/

/* CODIGO LICENCIADO EM MIT*/

/*
Função: Limpa_Buffer
Autor: Baseado em outras pessoas, modificada por Henrique.
Entradas:Stdin
Saídas: Nenhuma
Retorno: Nenhum

Objetivo: Consumir caracteres
adicionais presentes no stdin.
Se a função encontrar um EOF ela
Reseta o stdin para futuras leituras
*/
void limpa_buffer() {
    char caracter=0;									//Declara char para a leitura
    do {
    caracter = fgetc(stdin);							//Le caracter por caracter ate "zerar" stdin
    } while (caracter != '\n' && caracter!=EOF);		//Se foi encontrado uma quebra de linha ou um erro saia
    if(caracter==EOF)clearerr(stdin);					//Se foi encontrado um EOF, resete stdin
}

int main()
{
	int x,y,z;
	printf("Se sua entrada nao for processada, aperte \"enter\" DUAS vezes\n");	//Devido ao limpa_buffer que pode tentar ler quando nao ha entradas no buffer
	printf("Digite tres numeros (x,y,z): ");

	char *erro_leitura,teclado_entrada[35];								//Declara ponteiro de erro e um array para a leitura de dados
	//Eu posso ter numeros gigantes com 9 casas logo 9*3=27, portanto eu preciso de mais casas
	while(1)															//Eu consegui modularizar esse bloco mas preferi essa versão mais simples :)
	{
		erro_leitura=fgets(teclado_entrada,35,stdin);					//Le teclado e atribue um ponteiro como retorno para verificar erros
		limpa_buffer();													//Limpa o Buffer para a possivel proxima leitura
		if(erro_leitura!=NULL || (teclado_entrada[0]!='\n'
									&& strlen(teclado_entrada)!=1) )	//Houve erro de leitura? o Usuario digitou "enter"?
		{
			erro_leitura=(char *)malloc(1*sizeof(char));				//Se não houve, aloque uma char para o ponteiro
			*erro_leitura=(char)sscanf(teclado_entrada,"%d%d%d",&x,&y,&z);		//Atribua as variaveis os valores
																		//O erro da leitura sera atribuido ao char alocado
			if(*erro_leitura!=-1 && *erro_leitura==3 )					//Não houve erro na atribuição?FOI DIGITADO TRES NUMEROS?
			{
				free(erro_leitura);										//Desaloca o char da memória
				break;													//Sai do Loop While
			}
			free(erro_leitura);											//Desaloca o char da memória
		}
		printf("\nErro digite novamente: ");							//Se algo deu errado tente novamente
	}//End While(1)

	printf("Selecione as operacoes:\n");	//Pede as opcoes
	printf("1)Maior e menor - Calcule o maior e o menor dentre os três números\n");
	printf("2)Testa divisão - Teste se x é divisı́vel por y e, depois, se x é divisı́vel por z\n");
	printf("3)Raiz quadrada - Calcula a raiz quadrada de cada número, se ele for positivo e par, ou eleva ao quadrado, caso seja ı́mpar;\n");
	printf("4)Triplo da exponencial - Calcula o triplo da exponencial de cada número (ex: 3e^x )\n");
	printf("Sua opcao: ");

	erro_leitura=(char *)malloc(1*sizeof(char));
	*erro_leitura=getchar();
	switch (*erro_leitura)		//To cansando nao quero mais pensar kkk so vamo fazer cada um
	{
		case '1':
			if(x>y){
				if(x>z)
				{
					printf("O numero X(%d) eh o maior ",x);
					if(y>z)printf("\nO numero Z(%d) eh o menor ",z);
					else printf("\nO numero Y(%d) eh o menor ",y);
				}
			}
			else if (y>z){
				printf("O numero Y(%d) eh o maior ",y);
				if(x>z)printf("\nO numero Z(%d) eh o menor ",z);
				else printf("O numero X(%d) eh o menor ",x);
			}
			else{
				printf("\nO numero Z(%d) eh o maior ",z);
				printf("\nO numero X(%d) eh o menor ",x);
			}
			break;
		case '2':
			if(x%y==0)printf("X eh divisivel por Y");
			else if (x%z==0)printf("X eh divisivel por Z");
			else printf("X nao eh divisivel por ninguem");
			break;
		case '3':
			if(x%2==0 && x>0)printf("\n Raiz quadrada de X(%d)=%f",x,sqrtf((float)x));
			else printf("\nX(%d) ao quadrado = %f",x,pow((float)x,2.0));

			if(y%2==0 && y>0)printf("\n Raiz quadrada de Y(%d)=%f",y,sqrtf((float)y));
			else printf("\nY(%d) ao quadrado = %f",y,pow((float)y,2.0));

			if(z%2==0 && z>0)printf("\n Raiz quadrada de Z(%d)=%f",z,sqrtf((float)z));
			else printf("\nZ(%d) ao quadrado = %f",z,pow((float)z,2.0));
			break;
		case '4':
			printf("Triplo da exponencial de X(%d)= %f\n",x, 3.0*expf( (float) x) );
			printf("Triplo da exponencial de Y(%d)= %f\n",y, 3.0*expf( (float) y) );
			printf("Triplo da exponencial de Z(%d)= %f",z, 3.0*expf( (float) z) );
			break;
	}
    return 0;
}
//Estou enviando na terca feira de noite e
//os comentarios foram embora com o goto ... tenha um bom dia
