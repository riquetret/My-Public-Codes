#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
* Lab. de Programa��o de Computadores I - Laborat�rio 03
*
* Aluno(a): Henrique Soares Costa e Roginaldo Rebou�as Rocha Junior
* Data: 25/11/2021
* Vers�o: 1.0
* Atividade 1 - Resultado do Somatorio
*/

/* CODIGO LICENCIADO EM MIT*/

/*
Fun��o: Limpa_Buffer
Autor: Baseado em outras pessoas, modificada por Henrique.
Entradas:Stdin
Sa�das: Nenhuma
Retorno: Nenhum

Objetivo: Consumir caracteres
adicionais presentes no stdin.
Se a fun��o encontrar um EOF ela
Reseta o stdin para futuras leituras
*/
void limpa_buffer() {
    char caracter=0;									//Declara char para a leitura
    do {
    caracter = fgetc(stdin);							//Le caracter por caracter ate "zerar" stdin
    } while (caracter != '\n' && caracter!=EOF);		//Se foi encontrado uma quebra de linha ou um erro saia
    if(caracter==EOF)clearerr(stdin);					//Se foi encontrado um EOF, resete stdin
}

int main()
{
    int numero_lido,inicializador;						//Declar numero_lido para leitura, inicializador para o loop e
    long int resultado_soma=0;								//Resultado soma para acumular a soma, long it para nao dar overflow
	printf("Se sua entrada nao for processada, aperte \"enter\" DUAS vezes\n");	//Devido ao limpa_buffer que pode tentar ler quando nao ha entradas no buffer
    printf("Digite um numero para o somatorio dos numeros anteriores a ele: "); //Pede Requisi��o do usu�rio


    char *erro_leitura,teclado_entrada[7];								//Declara ponteiro de erro e um array para a leitura de dados
	//Eu quero numero de at� 6 digitos por precau��o para nao dar overflow
	while(1)															//Eu n�o consegui modularizar esse while :(
	{
		erro_leitura=fgets(teclado_entrada,7,stdin);					//Le teclado e atribue um ponteiro como retorno para verificar erros
		limpa_buffer();													//Limpa o Buffer para a possivel proxima leitura
		if(erro_leitura!=NULL || (teclado_entrada[0]!='\n'
									&& strlen(teclado_entrada)!=1) )	//Houve erro de leitura? o Usuario digitou "enter"?
		{
			erro_leitura=(char *)malloc(1*sizeof(char));				//Se n�o houve, aloque uma char para o ponteiro
			*erro_leitura=(char)sscanf(teclado_entrada,"%d",&numero_lido);		//Atribua a variavel ano um valor decimal
																		//O erro da leitura sera atribuido ao char alocado
			if(*erro_leitura!=-1 && *erro_leitura!=0 && numero_lido>0)	//N�o houve erro na atribui��o? O numero digitado est� correto?
			{
				free(erro_leitura);										//Desaloca o char da mem�ria
				break;													//Sai do Loop While
			}
			free(erro_leitura);											//Desaloca o char da mem�ria
		}
		printf("\nErro digite novamente: ");							//Se algo deu errado tente novamente
	}//End While(1)


    for(inicializador=1;inicializador!=(numero_lido+1);inicializador++)	//Inicializa inicializador e conta at� o numero_lido+1
    {
        resultado_soma =  resultado_soma + inicializador ;				//Acumula a soma
    }
    printf("\nResultado do somatorio = %d\n",resultado_soma);				//Exibe o resultado da soma

    return 0;
}
