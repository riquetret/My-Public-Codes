#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
* Lab. de Programação de Computadores I - Laboratório 03
*
* Aluno(a): Henrique Soares Costa e Roginaldo Rebouças Rocha Junior
* Data: 25/11/2021
* Versão: 1.0
* Atividade 4 - Número de 1 ate 20
*/

/* CODIGO LICENCIADO EM MIT*/

int main()
{

	//Declara numero inicial,"i" para ser nosso iterador
	int numero=1,i;
	for(;numero<20;)	//Exiba na tela o numero ate i ser maior ou igual a 20
	{
		for(i=5;i;i--)	//Sao 5 colunas logo i=5 com 5 loops
		{
			printf("%d ",numero);	//Exibi numero
			numero++;				//Incrementa o numero
		}
		printf("\n");				//Terminou a linha logo pule para a proxima linha
	}
    return 0;
}
