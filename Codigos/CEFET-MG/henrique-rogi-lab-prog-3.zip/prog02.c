#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
* Lab. de Programação de Computadores I - Laboratório 03
*
* Aluno(a): Henrique Soares Costa e Roginaldo Rebouças Rocha Junior
* Data: 25/11/2021
* Versão: 1.0
* Ativade 2 - Número para Ano
*/

/* CODIGO LICENCIADO EM MIT*/

/*
Função: Limpa_Buffer
Entradas:Stdin
Saídas: Nenhuma
Retorno: Nenhum

Objetivo: Consumir caracteres
adicionais presentes no stdin.
Se a função encontrar um EOF ela
Reseta o stdin para futuras leituras
*/
void limpa_buffer() {
    char caracter=0;									//Declara char para a leitura
    do {
    caracter = fgetc(stdin);							//Le caracter por caracter ate "zerar" stdin
    } while (caracter != '\n' && caracter!=EOF);		//Se foi encontrado uma quebra de linha ou um erro saia
    if(caracter==EOF)clearerr(stdin);					//Se foi encontrado um EOF, resete stdin
}

int main()
{

	int ano;															//Variavel Ano para a leitura
	printf("Bem Vindo ao Programa Numero para Mes.\n");					//Observações Iniciais
	printf("Se sua entrada nao for processada, aperte \"enter\" DUAS vezes\n");	//Devido ao limpa_buffer que pode tentar ler quando nao ha entradas no buffer
	printf("Digite um numero para ver seu correspondente em mes: ");

	char *erro_leitura,teclado_entrada[3];								//Declara ponteiro de erro e um array para a leitura de dados
	//Eu quero ler so dois digitos, portanto preciso de 3 casas para acomodar o \0
	while(1)															//Eu não consegui modularizar esse while :(
	{
		erro_leitura=fgets(teclado_entrada,3,stdin);					//Le teclado e atribue um ponteiro como retorno para verificar erros
		limpa_buffer();													//Limpa o Buffer para a possivel proxima leitura
		if(erro_leitura!=NULL || (teclado_entrada[0]!='\n'
									&& strlen(teclado_entrada)!=1) )	//Houve erro de leitura? o Usuario digitou "enter"?
		{
			erro_leitura=(char *)malloc(1*sizeof(char));				//Se não houve, aloque uma char para o ponteiro
			*erro_leitura=(char)sscanf(teclado_entrada,"%d",&ano);		//Atribua a variavel ano um valor decimal
																		//O erro da leitura sera atribuido ao char alocado
			if(*erro_leitura!=-1 && *erro_leitura!=0 && (ano>0 && ano<13))	//Não houve erro na atribuição? O ano digitado está correto?
			{
				free(erro_leitura);										//Desaloca o char da memória
				break;													//Sai do Loop While
			}
			free(erro_leitura);											//Desaloca o char da memória
		}
		printf("\nErro digite novamente: ");							//Se algo deu errado tente novamente
	}//End While(1)

	switch (ano)														//Analisa qual o conteúdo de ano
	{
		case 1:															//Se ano==1, então...
			printf("\nO ano escolhido foi Janeiro");					//Exibe Janeiro na tela
			break;														//Break para sair do switch e nao continuar executando
		case 2:															//E assim vai
			printf("\nO ano escolhido foi Fevereiro");
			break;
		case 3:
			printf("\nO ano escolhido foi Marco");
			break;
		case 4:
			printf("\nO ano escolhido foi Abril");
			break;
		case 5:
			printf("\nO ano escolhido foi Maio");
			break;
		case 6:
			printf("\nO ano escolhido foi Junho");
			break;
		case 7:
			printf("\nO ano escolhido foi Julho");
			break;
		case 8:
			printf("\nO ano escolhido foi Agosto");
			break;
		case 9:
			printf("\nO ano escolhido foi Setembro");
			break;
		case 10:
			printf("\nO ano escolhido foi Outubro");
			break;
		case 11:
			printf("\nO ano escolhido foi Novembro");
			break;
		default:														//Se 12 ou qualquer outra coisa, mostre dezembro
			printf("O ano escolhido foi Dezembro");
	}//END SWITCH (ano)
    return 0;
}
