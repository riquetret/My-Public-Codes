#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
* Lab. de Programação de Computadores I - Laboratório 03
*
* Aluno(a): Henrique Soares Costa e Roginaldo Rebouças Rocha Junior
* Data: 25/11/2021
* Versão: 1.0
* Atividade 6 - Ano Bissexto
*/

/* CODIGO LICENCIADO EM MIT*/

/*
Função: Limpa_Buffer
Autor: Baseado em outras pessoas, modificada por Henrique.
Entradas:Stdin
Saídas: Nenhuma
Retorno: Nenhum

Objetivo: Consumir caracteres
adicionais presentes no stdin.
Se a função encontrar um EOF ela
Reseta o stdin para futuras leituras
*/
void limpa_buffer() {
    char caracter=0;									//Declara char para a leitura
    do {
    caracter = fgetc(stdin);							//Le caracter por caracter ate "zerar" stdin
    } while (caracter != '\n' && caracter!=EOF);		//Se foi encontrado uma quebra de linha ou um erro saia
    if(caracter==EOF)clearerr(stdin);					//Se foi encontrado um EOF, resete stdin
}

int main()
{
	int ano;
	printf("Se sua entrada nao for processada, aperte \"enter\" DUAS vezes\n");	//Devido ao limpa_buffer que pode tentar ler quando nao ha entradas no buffer
	printf("Digite um ano de 0 até 9999:  ");
	char *erro_leitura,teclado_entrada[5];								//Declara ponteiro de erro e um array para a leitura de dados
	//Eu vou limitar os anos ate 9999, logo precisamos de 5 entradas no array
	while(1)															//Eu não consegui modularizar esse while :(
	{
		erro_leitura=fgets(teclado_entrada,5,stdin);					//Le teclado e atribue um ponteiro como retorno para verificar erros
		limpa_buffer();													//Limpa o Buffer para a possivel proxima leitura
		if(erro_leitura!=NULL || (teclado_entrada[0]!='\n'
									&& strlen(teclado_entrada)!=1) )	//Houve erro de leitura? o Usuario digitou "enter"?
		{
			erro_leitura=(char *)malloc(1*sizeof(char));				//Se não houve, aloque uma char para o ponteiro
			*erro_leitura=(char)sscanf(teclado_entrada,"%d",&ano);		//Atribua a variavel ano um valor decimal
																		//O erro da leitura sera atribuido ao char alocado
			if(*erro_leitura!=-1 && *erro_leitura!=0 && ano>0)			//Não houve erro na atribuição? O ano digitado está correto?
			{
				free(erro_leitura);										//Desaloca o char da memória
				break;													//Sai do Loop While
			}
			free(erro_leitura);											//Desaloca o char da memória
		}
		printf("\nErro digite novamente: ");							//Se algo deu errado tente novamente
	}//End While(1)
	/*
	Para o ano ser bissexto ele precisa ser divisivel por 4 e não pode ser divisivel por 100
	mas se ele for divisivel por 100 ele precisa tambem ser divisel por 400 para ser bissexto
	*/
	if(ano%4 == 0)
	{
		if(ano%100 == 0)
		{
			if(ano%400 == 0)
			{
				printf("\nO ano digitado eh bissexto");
			}
			else printf("\nO ano digitado nao eh bissexto");
		}//END IF ANO%100
		else printf("\nO ano digitado é bissexto");
	}//END IF ANO%4
	else printf("\nO ano digitado nao eh bissexto");

    return 0;
}
